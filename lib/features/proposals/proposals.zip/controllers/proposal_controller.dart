import 'package:flutter/foundation.dart';

import '../models/proposal_model.dart';
import '../services/proposal_service.dart';

class ProposalController extends ChangeNotifier {
  final ProposalService _proposalService;

  ProposalController({ProposalService? proposalService})
    : _proposalService = proposalService ?? ProposalService();

  bool isLoading = false;
  String? errorMessage;

  Future<bool> submitProposal({
    required String projectId,
    required String message,
    required String priceText,
    required String estimatedTime,
    required String workMethod,
  }) async {
    errorMessage = null;

    final cleanMessage = message.trim();
    final cleanPriceText = priceText.trim();
    final cleanEstimatedTime = estimatedTime.trim();
    final cleanWorkMethod = workMethod.trim();

    if (cleanMessage.isEmpty) {
      errorMessage = 'Pesan proposal wajib diisi.';
      notifyListeners();
      return false;
    }

    if (cleanPriceText.isEmpty) {
      errorMessage = 'Harga proposal wajib diisi.';
      notifyListeners();
      return false;
    }

    final price = double.tryParse(cleanPriceText);
    if (price == null) {
      errorMessage = 'Harga proposal harus berupa angka.';
      notifyListeners();
      return false;
    }

    if (price <= 0) {
      errorMessage = 'Harga proposal harus lebih dari 0.';
      notifyListeners();
      return false;
    }

    if (cleanEstimatedTime.isEmpty) {
      errorMessage = 'Estimasi waktu wajib diisi.';
      notifyListeners();
      return false;
    }

    if (cleanWorkMethod.isEmpty) {
      errorMessage = 'Metode kerja wajib diisi.';
      notifyListeners();
      return false;
    }

    _setLoading(true);

    try {
      final freelancerId = _proposalService.getCurrentUserId();

      final proposal = ProposalModel(
        projectId: projectId,
        freelancerId: freelancerId,
        message: cleanMessage,
        price: price,
        estimatedTime: cleanEstimatedTime,
        workMethod: cleanWorkMethod,
      );

      await _proposalService.createProposal(proposal);

      _setLoading(false);
      return true;
    } catch (error, stack) {
      debugPrint('[ProposalController] Error: $error');
      debugPrint('[ProposalController] Stack: $stack');
      errorMessage = _cleanError(error);
      _setLoading(false);
      return false;
    }
  }

  void _setLoading(bool value) {
    isLoading = value;
    notifyListeners();
  }

  String _cleanError(Object error) {
    final message = error.toString();

    if (message.contains('JWTExpired') || message.contains('not authenticated')) {
      return 'Sesi kamu telah berakhir. Silakan login ulang.';
    }

    if (message.contains('permission denied') || message.contains('row-level security')) {
      return 'Akses ditolak. Hanya freelancer yang dapat mengajukan proposal pada project yang terbuka (open).';
    }

    return 'Gagal mengirim proposal: $message';
  }
}
