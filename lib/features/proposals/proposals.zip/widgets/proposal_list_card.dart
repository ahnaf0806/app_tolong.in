import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_text_styles.dart';
import '../models/proposal_model.dart';

class ProposalListCard extends StatelessWidget {
  final ProposalModel proposal;
  final VoidCallback onAccept;
  final VoidCallback onReject;
  final bool isActionLoading;
  final bool canAct;

  const ProposalListCard({
    super.key,
    required this.proposal,
    required this.onAccept,
    required this.onReject,
    this.isActionLoading = false,
    this.canAct = true,
  });

  @override
  Widget build(BuildContext context) {
    final bool isPending = proposal.status == 'pending';
    final bool isAccepted = proposal.status == 'accepted';

    return Card(
      margin: const EdgeInsets.only(bottom: AppSpacing.md),
      shape: RoundedRectangleBorder(
        borderRadius: AppRadius.all(AppRadius.xl),
        side: BorderSide(
          color: isAccepted ? AppColors.success : AppColors.hairlineSoft,
          width: isAccepted ? 2 : 1,
        ),
      ),
      color: AppColors.canvas,
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundColor: AppColors.primary.withValues(alpha: 0.1),
                  child: const Icon(Icons.person, size: 16, color: AppColors.primary),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    proposal.freelancerName ?? 'Freelancer (ID: ${proposal.freelancerId.substring(0, 5)}...)',
                    style: AppTextStyles.bodyMdBold,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                _StatusBadge(status: proposal.status),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            
            _InfoRow(
              icon: Icons.payments_outlined,
              label: 'Harga Ditawarkan:',
              value: NumberFormat.currency(locale: 'id_ID', symbol: 'Rp', decimalDigits: 0).format(proposal.price),
            ),
            const SizedBox(height: AppSpacing.xs),
            _InfoRow(
              icon: Icons.access_time_rounded,
              label: 'Estimasi Waktu:',
              value: proposal.estimatedTime,
            ),
            const SizedBox(height: AppSpacing.md),

            Text('Pesan:', style: AppTextStyles.caption),
            const SizedBox(height: 2),
            Text(
              proposal.message,
              style: AppTextStyles.bodySm,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            
            if (isPending && canAct) ...[
              const SizedBox(height: AppSpacing.md),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: isActionLoading ? null : onReject,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.critical,
                        side: const BorderSide(color: AppColors.critical),
                        shape: RoundedRectangleBorder(borderRadius: AppRadius.all(AppRadius.lg)),
                      ),
                      child: const Text('Tolak'),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: isActionLoading ? null : onAccept,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.success,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: AppRadius.all(AppRadius.lg)),
                      ),
                      child: isActionLoading
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : const Text('Terima'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 14, color: AppColors.stone),
        const SizedBox(width: 4),
        Text(label, style: AppTextStyles.caption),
        const SizedBox(width: 4),
        Text(value, style: AppTextStyles.captionBold),
      ],
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String status;

  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    Color bgColor;
    String label;

    switch (status.toLowerCase()) {
      case 'accepted':
        label = 'Diterima';
        color = AppColors.success;
        bgColor = const Color(0xFFE8F5EC);
        break;
      case 'rejected':
        label = 'Ditolak';
        color = AppColors.critical;
        bgColor = const Color(0xFFFFECEF);
        break;
      default:
        label = 'Menunggu';
        color = AppColors.attention;
        bgColor = const Color(0xFFFFF4E0);
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.xxs),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: AppRadius.all(AppRadius.full),
      ),
      child: Text(
        label,
        style: AppTextStyles.caption.copyWith(color: color, fontWeight: FontWeight.w700),
      ),
    );
  }
}
