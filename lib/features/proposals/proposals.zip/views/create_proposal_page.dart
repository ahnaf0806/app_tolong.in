import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_radius.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../projects/models/project_model.dart';
import '../controllers/proposal_controller.dart';
import '../widgets/proposal_form_info_card.dart';

class CreateProposalPage extends StatefulWidget {
  final ProjectModel project;

  const CreateProposalPage({super.key, required this.project});

  @override
  State<CreateProposalPage> createState() => _CreateProposalPageState();
}

class _CreateProposalPageState extends State<CreateProposalPage> {
  final ProposalController _controller = ProposalController();

  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _estimatedTimeController = TextEditingController();
  final TextEditingController _workMethodController = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    _messageController.dispose();
    _priceController.dispose();
    _estimatedTimeController.dispose();
    _workMethodController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final success = await _controller.submitProposal(
      projectId: widget.project.id!,
      message: _messageController.text,
      priceText: _priceController.text,
      estimatedTime: _estimatedTimeController.text,
      workMethod: _workMethodController.text,
    );

    if (!mounted) {
      return;
    }

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Proposal berhasil dikirim.')),
      );
      Navigator.of(context).pop(); // Kembali ke halaman sebelumnya
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_controller.errorMessage ?? 'Proposal gagal dikirim.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.canvas,
      appBar: AppBar(
        title: const Text('Ajukan Proposal'),
        backgroundColor: AppColors.canvas,
        foregroundColor: AppColors.inkDeep,
        elevation: 0,
        scrolledUnderElevation: 1,
      ),
      body: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.all(AppSpacing.xl),
            children: [
              Text('Ajukan Proposal', style: AppTextStyles.headingSm),
              const SizedBox(height: AppSpacing.xs),
              Text(
                'Tawarkan kemampuan terbaikmu untuk project ini.',
                style: AppTextStyles.bodyMd,
              ),
              const SizedBox(height: AppSpacing.xl),

              ProposalFormInfoCard(project: widget.project),
              const SizedBox(height: AppSpacing.xxl),

              TextField(
                controller: _messageController,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'Pesan Penawaran',
                  hintText: 'Perkenalkan diri dan jelaskan mengapa kamu cocok mengerjakan project ini...',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: AppSpacing.base),

              TextField(
                controller: _priceController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Harga Penawaran (Rp)',
                  hintText: 'Contoh: 150000',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: AppSpacing.base),

              TextField(
                controller: _estimatedTimeController,
                decoration: const InputDecoration(
                  labelText: 'Estimasi Waktu Pengerjaan',
                  hintText: 'Contoh: 3 Hari / 1 Minggu',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: AppSpacing.base),

              TextField(
                controller: _workMethodController,
                decoration: const InputDecoration(
                  labelText: 'Metode Kerja',
                  hintText: 'Contoh: Menggunakan Figma, Revisi 2x',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: AppSpacing.xl),

              if (_controller.errorMessage != null) ...[
                Text(
                  _controller.errorMessage!,
                  style: AppTextStyles.bodySm.copyWith(color: AppColors.critical),
                ),
                const SizedBox(height: AppSpacing.base),
              ],

              SizedBox(
                height: 52,
                child: ElevatedButton(
                  onPressed: _controller.isLoading ? null : _submit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: AppColors.onPrimary,
                    shape: RoundedRectangleBorder(
                      borderRadius: AppRadius.all(AppRadius.xl),
                    ),
                  ),
                  child: _controller.isLoading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text('Kirim Proposal', style: AppTextStyles.buttonMd),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
