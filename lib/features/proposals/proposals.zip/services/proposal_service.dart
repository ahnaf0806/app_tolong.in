import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/services/supabase_service.dart';
import '../models/owner_proposal_item.dart';

class ProposalService {
  SupabaseClient get _client => SupabaseService.client;

  Future<void> createProposal(ProposalModel proposal) async {
    await _client.from('proposals').insert(proposal.toCreateJson());
  }

  Future<List<OwnerProposalItem>> getOwnerProposals() async {
    final ownerId = getCurrentUserId();

    final projectRows = await _client
        .from('projects')
        .select('id, title')
        .eq('owner_id', ownerId);

    final projects = projectRows as List;

    if (projects.isEmpty) {
      return [];
    }

    final projectIds = projects.map((item) => item['id'] as String).toList();

    final projectTitleMap = {
      for (final project in projects)
        project['id'] as String: project['title'] as String,
    };

    final proposalRows = await _client
        .from('proposals')
        .select(
          'id, project_id, freelancer_id, message, price, estimated_time, work_method, status, created_at',
        )
        .inFilter('project_id', projectIds)
        .order('created_at', ascending: false);

    final proposals = proposalRows as List;

    if (proposals.isEmpty) {
      return [];
    }

    final freelancerIds = proposals
        .map((item) => item['freelancer_id'] as String)
        .toSet()
        .toList();

    final profileRows = await _client
        .from('profiles')
        .select('id, name')
        .inFilter('id', freelancerIds);

    final profiles = profileRows as List;

    final freelancerNameMap = {
      for (final profile in profiles)
        profile['id'] as String: profile['name'] as String,
    };

    return proposals.map((proposal) {
      final projectId = proposal['project_id'] as String;
      final freelancerId = proposal['freelancer_id'] as String;

      return OwnerProposalItem.fromMaps(
        proposal: proposal,
        projectTitle: projectTitleMap[projectId] ?? 'Project',
        freelancerName: freelancerNameMap[freelancerId] ?? 'Freelancer',
      );
    }).toList();
  }

  Future<void> acceptProposal(OwnerProposalItem proposal) async {
    final ownerId = getCurrentUserId();

    final existingWorkspace = await _client
        .from('project_workspaces')
        .select('id')
        .eq('proposal_id', proposal.id)
        .maybeSingle();

    await _client
        .from('proposals')
        .update({'status': 'accepted'})
        .eq('id', proposal.id);

    await _client
        .from('proposals')
        .update({'status': 'rejected'})
        .eq('project_id', proposal.projectId)
        .neq('id', proposal.id)
        .eq('status', 'pending');

    await _client
        .from('projects')
        .update({'status': 'in_progress'})
        .eq('id', proposal.projectId);

    if (existingWorkspace == null) {
      await _client.from('project_workspaces').insert({
        'project_id': proposal.projectId,
        'owner_id': ownerId,
        'freelancer_id': proposal.freelancerId,
        'proposal_id': proposal.id,
        'status': 'active',
        'started_at': DateTime.now().toIso8601String(),
      });
    }
  }

  Future<void> rejectProposal(String proposalId) async {
    await _client
        .from('proposals')
        .update({'status': 'rejected'})
        .eq('id', proposalId);
  }

  /// Mengambil daftar proposal untuk suatu project
  Future<List<ProposalModel>> getProposalsByProjectId(String projectId) async {
    // Kita hapus join profiles jika FK belum ada.
    // Tapi karena di model kita handle opsional, kita coba join 'profiles(full_name)'.
    // Jika gagal, pastikan untuk menghapus join ini nantinya.
    final response = await _client
        .from('proposals')
        .select(
          'id, project_id, freelancer_id, message, price, estimated_time, work_method, status, created_at, profiles(full_name)',
        )
        .eq('project_id', projectId)
        .order('created_at', ascending: false);

    return (response as List)
        .map((item) => ProposalModel.fromJson(item))
        .toList();
  }

  /// Menolak sebuah proposal
  Future<void> rejectProposal(String proposalId) async {
    await _client
        .from('proposals')
        .update({'status': 'rejected'})
        .eq('id', proposalId);
  }

  /// Menerima sebuah proposal
  /// Akan mengubah status proposal menjadi 'accepted',
  /// menolak proposal lain di project yang sama,
  /// mengubah status project menjadi 'in_progress',
  /// dan membuat project_workspace.
  Future<void> acceptProposal({
    required String proposalId,
    required String projectId,
    required String freelancerId,
    required String ownerId,
  }) async {
    // 1. Terima proposal yang dipilih
    await _client
        .from('proposals')
        .update({'status': 'accepted'})
        .eq('id', proposalId);

    // 2. Tolak proposal lain yang masih pending di project ini
    await _client
        .from('proposals')
        .update({'status': 'rejected'})
        .eq('project_id', projectId)
        .eq('status', 'pending');

    // 3. Ubah status project
    await _client
        .from('projects')
        .update({'status': 'in_progress'})
        .eq('id', projectId);

    // 4. Buat workspace
    await _client.from('project_workspaces').insert({
      'project_id': projectId,
      'freelancer_id': freelancerId,
      'owner_id': ownerId,
      'status': 'active',
    });
  }

  String getCurrentUserId() {
    final user = _client.auth.currentUser;

    if (user == null) {
      throw Exception('User belum login.');
    }

    return user.id;
  }
}
